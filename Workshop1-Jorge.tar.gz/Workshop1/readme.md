# Workshop1
## Instalacion de virtualBox
Para proceder a la Instalacion de virtualBox debe obtener el instalador que corresponda a su
arquitectura de maquina anfitriona. Puede utilizar el siguiente enlace para hacer la descarga.

[Descargue aqui VirtualBox](https://virtualbox.org/wiki/Downloads)

## Instalacion de Vagrant
[Descargue aqui Vagrant](https://developer.hashicorp.com/vagrant/downloads?)

 ## Imagenes de prueba

![Imgur](https://i.imgur.com/9nOuj2K.jpg)

## Aprovisionamiento de la maquina virtual 
1 Crear y movernos a las carpetas correspondientes, para instalar lo que se necesite
```bash
mkdir isw811
cd isw811
cd workshop1
mkdir WMs
cd WMs
mkdir webserver
cd webserver

```
Lo siguiente es iniciar el archivo de Vagrant y abrirlo para config la ip
 ```bash
 vagrant init debian/bullseye64
 code Vagrantfile
```
Por ultimo faltaria levantar la maqyuba virtual y corroborar que todo funciona
```bash
vagrant up
vagrant status
vagrant ssh
vagrant halt
``` 
